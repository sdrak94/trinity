/**
 * 
 */
package cz.nxs.events.engine.stats;

import cz.nxs.interf.PlayerEventInfo;

/**
 * @author hNoke
 *
 */
public class EventSpecificStats extends EventStats
{
	public EventSpecificStats()
	{
		
	}
	
	@Override
	public void load()
	{
		
	}
	
	@Override
	public void onLogin(PlayerEventInfo player)
	{
		
	}

	@Override
	public void onDisconnect(PlayerEventInfo player)
	{
		
	}

	@Override
	public void onCommand(PlayerEventInfo player, String command)
	{
		
	}

	@Override
	public void statsChanged(PlayerEventInfo player)
	{
		
	}
}
