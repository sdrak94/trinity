package cz.nxs.events.engine.configtemplate;

/**
 * @author hNoke
 *
 */
public class ConfigTemplateManager 
{
	
}
