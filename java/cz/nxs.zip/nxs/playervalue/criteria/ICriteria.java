package cz.nxs.playervalue.criteria;

import cz.nxs.interf.PlayerEventInfo;

/**
 * @author hNoke
 *
 */
public interface ICriteria
{
	public int getPoints(PlayerEventInfo player);
}
