/**
 * 
 */
package cz.nxs.l2j;


/**
 * @author hNoke
 *
 */
public enum WeaponType
{
	SWORD,
	BLUNT,
	DAGGER,
	BOW,
	POLE,
	NONE,
	DUAL,
	ETC,
	FIST,
	DUALFIST,
	FISHINGROD,
	RAPIER,
	ANCIENTSWORD,
	CROSSBOW,
	FLAG,
	OWNTHING,
	DUALDAGGER,
	BIGBLUNT,
	BIGSWORD
}
