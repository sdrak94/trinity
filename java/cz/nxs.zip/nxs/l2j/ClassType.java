/**
 * 
 */
package cz.nxs.l2j;

/**
 * @author hNoke
 *
 */
public enum ClassType
{
	Fighter,
	Mystic,
	Priest
}
