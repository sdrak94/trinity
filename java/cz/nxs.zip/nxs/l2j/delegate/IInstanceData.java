/**
 * 
 */
package cz.nxs.l2j.delegate;

/**
 * @author hNoke
 *
 */
public interface IInstanceData
{
	public int getId();
	public String getName();
}
