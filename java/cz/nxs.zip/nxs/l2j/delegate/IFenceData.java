/**
 * 
 */
package cz.nxs.l2j.delegate;


/**
 * @author hNoke
 *
 */
public interface IFenceData
{
	public void deleteMe();
}
