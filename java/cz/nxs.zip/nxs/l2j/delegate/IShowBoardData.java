/**
 * 
 */
package cz.nxs.l2j.delegate;

import cz.nxs.interf.PlayerEventInfo;

/**
 * @author hNoke
 *
 */
public interface IShowBoardData
{
	public void sendToPlayer(PlayerEventInfo player);
}
